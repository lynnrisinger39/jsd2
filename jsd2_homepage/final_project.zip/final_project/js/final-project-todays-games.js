

// SETUP //
var gamesButton = document.querySelector(".gamesButton");
var todaysGames = document.querySelector(".todaysGames");
var url = "https://api.fantasydata.net/mlb/v2/JSON/BoxScores/2016-SEP-10&Ocp-Apim-Subscription-Key=5e2a5ce1853e470a81bd6355e3321b4c";


// events //

button.addEventListener('click', getTodaysGames)


function getTodaysGames(e){
	e.preventDefault();

	$.getJSON(url, gamesList)
}

function gamesList(data){
	var template = Handlebars.compile()
}

